# Dyna-MO PTM v0.3.0 retained starting structures

This preview contains 918 primary starting PDB files selected from
the frozen 1079-row Gate-3 release master.
The primary set contains 738 K/R systems and 180
phosphorylation batch-3 systems. Archive member identifiers exactly match the
release-master `system` identifiers.

The 161 phosphorylation batch-2 starting PDB files are not retained
in this checkout. They are listed only in `starting_structure_missing_v0.3.0.csv`. The
16 methyl-R systems rejected by the global MD-QC release gate
are listed separately in `starting_structure_quarantine_v0.3.0.csv`; they are neither primary archive
members nor missing-release rows.

For methyl-R, the AlphaFold 3 input PDB keeps CCD component AGM at the modified
site. The simulation topology uses MD residue RM1. Both fields are explicit in
the primary manifest and quarantine ledger. Each inspected PDB has at least one
ATOM/HETATM record with the expected input component at the released site.

The metadata beside this archive locks the frozen Gate-3 metadata, release
master, quarantine ledger, and batch-3 mapping by SHA-256. This is a preview,
not an official submission or dist release.
